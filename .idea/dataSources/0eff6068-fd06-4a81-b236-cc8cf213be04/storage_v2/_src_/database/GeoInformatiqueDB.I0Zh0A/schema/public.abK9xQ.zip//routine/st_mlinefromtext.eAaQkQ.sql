create function st_mlinefromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1,$2)
	ELSE NULL END

$$;

comment on function st_mlinefromtext(text, integer) is 'args: WKT, srid - Return a specified ST_MultiLineString value from WKT representation.';

alter function st_mlinefromtext(text, integer) owner to postgres;

