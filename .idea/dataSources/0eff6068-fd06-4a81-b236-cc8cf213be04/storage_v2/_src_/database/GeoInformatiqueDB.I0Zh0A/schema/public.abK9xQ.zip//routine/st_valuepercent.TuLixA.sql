create function st_valuepercent(rast raster, searchvalue double precision, roundto double precision DEFAULT 0) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ( public._ST_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).percent
$$;

alter function st_valuepercent(raster, double precision, double precision) owner to postgres;

