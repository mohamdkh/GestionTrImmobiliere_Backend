create function st_voronoilines(g1 geometry, tolerance double precision DEFAULT 0.0, extend_to geometry DEFAULT NULL::geometry) returns geometry
    immutable
    parallel safe
    cost 1
    language sql
as
$$
SELECT public._ST_Voronoi(g1, extend_to, tolerance, false)
$$;

comment on function st_voronoilines(geometry, double precision, geometry) is 'args: g1, tolerance, extend_to - Returns the boundaries between the cells of the Voronoi diagram constructed from the vertices of a geometry.';

alter function st_voronoilines(geometry, double precision, geometry) owner to postgres;

