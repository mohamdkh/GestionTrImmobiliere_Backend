create function st_polygon(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_SetSRID(public.ST_MakePolygon($1), $2)

$$;

comment on function st_polygon(geometry, integer) is 'args: aLineString, srid - Returns a polygon built from the specified linestring and SRID.';

alter function st_polygon(geometry, integer) owner to postgres;

