create function st_approxquantile(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 0.1, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_quantile($1, $2, $3, $4, $5)
$$;

alter function st_approxquantile(raster, integer, boolean, double precision, double precision[], out double precision, out double precision) owner to postgres;

